define(function(require) {
    "use strict";

    var Backbone = require("backbone");
    var radio = require('radio').channel("app");
    var THREE = require("three");
    var msgpack = require("/js/libs/msgpack.js");

    var EDGES_MODES = {
        "no edges": 0,
        "hard edges": 1,
        "mesh edges": 2
    };
    var VIEWCUT_MODES = {
        "intersection": "&&",
        "union": "||",
        "difference": "^^"
    };
    var DEFAULT_COLOR_MAP = [
        new THREE.Color(0.164, 0.043, 0.850),
        new THREE.Color(0.150, 0.306, 1.000),
        new THREE.Color(0.250, 0.630, 1.000),
        new THREE.Color(0.450, 0.853, 1.000),
        new THREE.Color(0.670, 0.973, 1.000),
        new THREE.Color(0.880, 1.000, 1.000),
        new THREE.Color(1.000, 1.000, 0.750),
        new THREE.Color(1.000, 0.880, 0.600),
        new THREE.Color(1.000, 0.679, 0.450),
        new THREE.Color(0.970, 0.430, 0.370),
        new THREE.Color(0.850, 0.150, 0.196),
        new THREE.Color(0.650, 0.000, 0.130)
    ];

    var Model = Backbone.Model.extend({

        _defaults: { // Backbone's defaults won't trigger the events, done manually during setup
            "showPart": true,
            "edges": "no edges",
            "nodes": false,

            "result": '',
            "minResultVertex": null,
            "maxResultVertex": null,

            "colorMap": DEFAULT_COLOR_MAP,
            "minColor": new THREE.Color(0.2, 0.2, 0.2),
            "maxColor": new THREE.Color(1, 0, 1),
            "minContourValue": '',
            "maxContourValue": '',

            "isolines": true,
            "lights": true,
            "viewcuts": [],
            "viewcutMode": "intersection"
        },

        initialize: function() {
            this.urlRoot = radio.request("data:root");
            this.fetch();

            this.on({
                "change:showPart": function () {
                    this.mesh.visible = this.get("showPart");
                },
                "change:edges": function (model, value) {
                    this.showEdges(value);
                },
                "change:nodes": function (model, value) {
                    this.showNodes(value);
                },

                "change:result": function (model, value) {
                    this.setResult(value);
                },
                "change:minResultVertex": function () {
                    var attrName = this.get("result");
                    if (!attrName) return;
                    var minVal = this.data.getAttribute(attrName).array[ this.get("minResultVertex") ];
                    this.set("minContourValue",minVal);
                },
                "change:maxResultVertex": function () {
                    var attrName = this.get("result");
                    if (!attrName) return;
                    var maxVal = this.data.getAttribute(attrName).array[ this.get("maxResultVertex") ];
                    this.set("maxContourValue",maxVal);
                },

                "change:colorMap": function (model, value) {
                    this.setColorMap(value);
                },
                "change:minColor": function (model, value) {
                    this.setMinColor(value);
                },
                "change:maxColor": function (model, value) {
                    this.setMaxColor(value);
                },
                "change:minContourValue": function (model, value) {
                    this.setMinContourValue(value);
                },
                "change:maxContourValue": function (model, value) {
                    this.setMaxContourValue(value);
                },

                "change:isolines": function (model, value) {
                    this.showIsolines(value);
                },
                "change:lights": function (model, value) {
                    this.showLights(value);
                },
                "change:viewcuts": function (model, value) {
                    this.setViewcuts(value);
                },
                "change:viewcutMode": function (model, value) {
                    this.setViewcutMode(value);
                }
            }, this);
        },

        sync: function(method, model, options) {

            var xhr = new XMLHttpRequest();
            xhr.open('GET', model.url(), true);
            xhr.responseType = 'arraybuffer';

            xhr.onload = function(event) {
                radio.trigger("model:loaded");
                setTimeout(function () {
                    var decoded = msgpack.decode(xhr.response);
                    var loader = new THREE.BufferGeometryLoader();
                    model.setup( loader.parse( decoded ) );
                    options.success();
                }, 40);
            };

            xhr.onprogress = function(event) {
                radio.trigger("model:progress", event.loaded/event.total);
            };

            xhr.send();
        },

        setup: function(geometry) {

            this.data = geometry;

            // setup geometry
            var position = new Float32Array(geometry.index.count * 3);
            for ( var i = 0; i < geometry.index.count; i++) {
                position[3*i] = geometry.attributes.position.array[ 3*geometry.index.array[i] ];
                position[3*i + 1] = geometry.attributes.position.array[ 3*geometry.index.array[i] + 1];
                position[3*i + 2] = geometry.attributes.position.array[ 3*geometry.index.array[i] + 2];
            };

            var bufferGeo = new THREE.BufferGeometry();
            bufferGeo.addAttribute('position', new THREE.BufferAttribute(position, 3));
            bufferGeo.computeBoundingSphere();
            bufferGeo.computeVertexNormals();
            bufferGeo.normalizeNormals();

            // setup material
            var materialMesh = new THREE.ShaderMaterial({
                uniforms: THREE.UniformsUtils.merge([
                    THREE.UniformsLib['lights'],
                    {
                        diffuseColor: {type: "c", value: new THREE.Color( 0xeeeeee )},
                        minContourValue: {type: "f"},
                        maxContourValue: {type: "f"},
                        delta: {type: "f"},
                        minColor: {type: "c"},
                        maxColor: {type: "c"},
                        colorMap: {type: "t"},
                        viewcuts: {type: "sa", value: [], properties: {
                            "point": {type: "v3"},
                            "normal": {type: "v3"}
                        }}
                    }
                ]),
                defines: {
                    EDGES_NO: EDGES_MODES["no edges"],
                    EDGES_HARD: EDGES_MODES["hard edges"],
                    EDGES_MESH: EDGES_MODES["mesh edges"]
                },
                vertexShader: require("text!./shaders/colorMap.vert"),
                fragmentShader: require("text!./shaders/colorMap.frag"),
                side: THREE.DoubleSide,
                lights: true
            });
            materialMesh.extensions.derivatives = true;

            this.mesh = new THREE.Mesh( bufferGeo, materialMesh );

            // setup model attributes
            this.set(this._defaults);
            this.setupBarycentric();

            // setup nodes
            var geometryNodes = new THREE.BufferGeometry();
            geometryNodes.addAttribute('position', geometry.attributes.position);
            geometryNodes.addAttribute('nodenum', geometry.attributes.nodenum);
            var materialNodes = new THREE.PointsMaterial();

            this.nodes = new THREE.Points( geometryNodes, materialNodes );
        },

        setupBarycentric: function () {
            if ( this.mesh.geometry.getAttribute('barycentric') ) return;

            var BC = [ // barycentric coordinates values at vertices of triangle
                [1, 0, 0],
                [0, 1, 0],
                [0, 0, 1]
            ];
            var barycentric = new Float32Array(this.data.index.count * 3);

            for ( var i = 0; i < this.data.index.count; i++) {
                barycentric[3*i] = BC[i % 3][0];
                barycentric[3*i + 1] = BC[i % 3][1];
                barycentric[3*i + 2] = BC[i % 3][2];
            };

            this.mesh.geometry.addAttribute('barycentric', new THREE.BufferAttribute(barycentric, 3));

            this.mesh.material.defines.BARYCENTRIC = '';
            this.mesh.material.needsUpdate = true;
        },

        /**
         * Set colormap texture and pass it as uniform to shaders
         * @param {THREE.Color[]} colorMap
         */
        setColorMap: function (colorMap) {
            var texture = [];
            for (var i = 0; i < colorMap.length; i++) {
                texture = texture.concat( colorMap[i].toArray() );
            };

            this.mesh.material.uniforms.colorMap = {
                type: "t",
                value: new THREE.DataTexture(
                    new Float32Array(texture),
                    colorMap.length,
                    1,
                    THREE.RGBFormat,
                    THREE.FloatType
                )
            };
            this.mesh.material.uniforms.colorMap.value.needsUpdate = true;
            this.mesh.material.needsUpdate = true;

            this.mesh.material.uniforms.delta.value = 1./colorMap.length;
        },

        setMinContourValue: function (value) {
            var attrName = this.get("result");
            if (!attrName) return;

            this.mesh.material.uniforms.minContourValue.value = value ||
                this.data.getAttribute(attrName).array[ this.get("minResultVertex") ];
        },

        setMaxContourValue: function (value) {
            var attrName = this.get("result");
            if (!attrName) return;

            this.mesh.material.uniforms.maxContourValue.value = value ||
                this.data.getAttribute(attrName).array[ this.get("maxResultVertex") ];
        },

        setMinColor: function (minColor) {
            if (minColor) {
                this.mesh.material.uniforms.minColor.value = minColor;
                this.mesh.material.defines.USE_MIN_COLOR = '';
            } else {
                delete this.mesh.material.defines.USE_MIN_COLOR;
            }
            this.mesh.material.needsUpdate = true;
        },

        setMaxColor: function (maxColor) {
            if (maxColor) {
                this.mesh.material.uniforms.maxColor.value = maxColor;
                this.mesh.material.defines.USE_MAX_COLOR = '';
            } else {
                delete this.mesh.material.defines.USE_MAX_COLOR;
            }
            this.mesh.material.needsUpdate = true;
        },

        showIsolines: function (isolines) {
            if (isolines) {
                this.mesh.material.defines.ISOLINES = '';
            } else {
                delete this.mesh.material.defines.ISOLINES;
            };
            this.mesh.material.needsUpdate = true;
        },

        showLights: function (lights) {
            if (lights) {
                this.mesh.material.defines.LIGHTS = '';
            } else {
                delete this.mesh.material.defines.LIGHTS;
            };
            this.mesh.material.needsUpdate = true;
        },

        setViewcuts: function (viewcuts) {
            this.mesh.material.defines.NUM_VIEWCUTS = viewcuts.length;
            this.mesh.material.needsUpdate = true;
            this.mesh.material.uniforms.viewcuts.value = viewcuts;
        },

        setViewcutMode: function (viewcutMode) {
            this.mesh.material.defines.VIEWCUT_OPERATOR = VIEWCUT_MODES[viewcutMode];
            this.mesh.material.needsUpdate = true;
        },

        showEdges: function (edges) {
            this.mesh.material.defines.EDGES_MODE = EDGES_MODES[edges];
            this.mesh.material.needsUpdate = true;
        },

        showNodes: function (nodes) {
            if (nodes) {
                this.mesh.material.defines.NODES = '';
            } else {
                delete this.mesh.material.defines.NODES;
            };
            this.mesh.material.needsUpdate = true;
        },

        setResult: function (attrName) {
            if (attrName) {
                var array = this.data.getAttribute(attrName).array;

                // setup 'value' attribute passed to vertex shader
                var value = new Float32Array(this.data.index.count);
                for ( var i = 0; i < this.data.index.count; i++) {
                    value[i] = this.data.getAttribute(attrName).array[ this.data.index.array[i] ];
                };
                if (this.mesh.geometry.getAttribute('value')) {
                    this.mesh.geometry.getAttribute('value').set(value);
                    this.mesh.geometry.getAttribute('value').needsUpdate = true;
                } else {
                    this.mesh.geometry.addAttribute('value', new THREE.BufferAttribute(value, 1));
                };

                this.mesh.material.defines.RESULT = '';

                this.findMinResultVertex();
                this.findMaxResultVertex();
            } else {
                this.mesh.geometry.removeAttribute('value');
                delete this.mesh.material.defines.RESULT;
            };
            this.mesh.material.needsUpdate = true;
        },

        findMinResultVertex: function () {
            var attrName = this.get("result");
            var array = this.data.getAttribute(attrName).array;

            // find minimum vertex
            var vertex = 0;
            for (var i = 1; i < array.length; i++) {
                if (array[i] < array[vertex]) {
                    vertex = i;
                }
            };

            this.set('minResultVertex', vertex);
        },

        findMaxResultVertex: function () {
            var attrName = this.get("result");
            var array = this.data.getAttribute(attrName).array;

            // find maximum vertex
            var vertex = 0;
            for (var i = 1; i < array.length; i++) {
                if (array[i] > array[vertex]) {
                    vertex = i;
                }
            };

            this.set('maxResultVertex', vertex);
        },

        queryNode: function(vIndex) {
            return {
                nodenum: this.data.attributes.nodenum.array[vIndex],
                TDAM: this.data.attributes.TDAM.array[vIndex],
                SIGR: this.data.attributes.SIGR.array[vIndex],
                CYCL: this.data.attributes.CYCL.array[vIndex]
            };
        }

    });

    return Model;

});
