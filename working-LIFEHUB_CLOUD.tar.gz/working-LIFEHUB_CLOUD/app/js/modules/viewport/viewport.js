define(function(require) {
    "use strict";

    var $ = require("jquery");
    var _ = require("underscore");
    var Backbone = require("backbone");
    var radio = require("radio").channel("app");
    var THREE = require("three");
    require('threeControls');

    var Loader = require("./loader/loader");
    var Options = require("./options/options");
    var Query = require("./query/query");
    var Legend = require("./legend/legend");
    var minMaxVert = require("./minMax/minMaxVert");

    var INTERSECTED = null;
    var HIGHLIGHT_SIZE = 1;
    var HIGHLIGHT_THRESHOLD = 1;
    var mouse = new THREE.Vector2();

    var Viewport = Backbone.View.extend({

        events: {
            "mousemove canvas": "updateMouse",
            "click canvas": "selectNode",
            "contextmenu canvas": "selectRotationCenter"
        },

        initialize: function() {
            this.listenTo(this.model, "sync", this.render);
            this.loader = new Loader();
            this.$el.append(this.loader.render().$el);
            this.onResize = this.onResize.bind(this);
            $(window).on('resize', this.onResize);
        },

        remove: function() {
            cancelAnimationFrame(this.animationFrame);

            $(window).off("resize", this.onResize);
            this.stopListening();
            this.undelegateEvents();

            this.options.remove();
            this.query.remove();
            this.legend.remove();
            this.minVert.remove();
            this.maxVert.remove();
            // this.options = undefined;

            for (var i = this.scene.children.length - 1; i >= 0; --i){
                var child = this.scene.children[i];
                if (child.parent) child.parent.remove(child);
                if (child.geometry) child.geometry.dispose();
                if (child.material) child.material.dispose();
            };
            // this.model = undefined;

            this.$(this.renderer.domElement).remove();
            this.renderer.dispose();
            // this.renderer = undefined;

            // this.markerHighlight = undefined;
            // this.markerSelect = undefined;
            // this.rotationCenter = undefined;

            this.controls.dispose();

            return this;
        },

        render: function () {

            var sceneSize = this.model.mesh.geometry.boundingSphere.radius;
            HIGHLIGHT_SIZE = sceneSize/100.0;
            var modelCenter = this.model.mesh.geometry.boundingSphere.center;

            // SCENE
            this.scene = new THREE.Scene();

            // GEOMETRY
            this.scene.add(this.model.mesh);

            // CAMERA
            this.camera = new THREE.OrthographicCamera(
                -sceneSize * this.$el.width() / this.$el.height(),
                sceneSize * this.$el.width() / this.$el.height(),
                sceneSize,
                -sceneSize,
                -10*sceneSize,
                10*sceneSize
            );
            this.camera.zoom = 1;
            this.camera.position.set(sceneSize,sceneSize,sceneSize).add(modelCenter);
            this.camera.lookAt(modelCenter);
            this.camera.updateProjectionMatrix();
            this.scene.add(this.camera);

            // RENDERER
            this.renderer = new THREE.WebGLRenderer({ antialias: true });
            this.renderer.setSize( this.$el.width(), this.$el.height() );
            this.renderer.setClearColor(0xffffff);
            this.$el.append(this.renderer.domElement);

            // CONTROLS
            this.controls = new THREE.OrthographicTrackballControls( this.camera, this.renderer.domElement);
            this.controls.target.copy(modelCenter);
            this.controls.staticMoving = true;

            // LIGHT
            this.light = new THREE.AmbientLight( 0x909090 ); // soft white light
            this.scene.add(this.light);

            this.directionalLight = new THREE.DirectionalLight( 0xffffff, 0.5 );
            this.directionalLight.position.set( 1, 1, 1 ).normalize();
            this.scene.add( this.directionalLight );

            this.directionalLight2 = new THREE.DirectionalLight( 0xffffff, 0.5 );
            this.directionalLight2.position.set( -1, -1, -1 ).normalize();
            this.scene.add( this.directionalLight2 );

            // RAYCASTER
            this.raycaster = new THREE.Raycaster();
            this.raycaster.params.Points.threshold = HIGHLIGHT_THRESHOLD;

            // Highlight marker
            this.markerHighlight = new THREE.Mesh(
                new THREE.SphereGeometry( HIGHLIGHT_SIZE, 32, 32 ),
                new THREE.MeshBasicMaterial( {color: 0xffaa00, depthTest: true} )
            );
            this.markerHighlight.visible = false;
            this.scene.add(this.markerHighlight);

            // Selection marker
            this.markerSelect = new THREE.Mesh(
                new THREE.SphereGeometry( HIGHLIGHT_SIZE, 32, 32 ),
                new THREE.MeshBasicMaterial( {color: 0xff0000, depthTest: true} )
            );
            this.markerSelect.visible = false;
            this.scene.add(this.markerSelect);

            // Rotation center marker
            this.rotationCenter = new THREE.AxisHelper( 5 );
            this.rotationCenter.position.copy(modelCenter);
            this.rotationCenter.material.depthTest = false;
            this.scene.add(this.rotationCenter);

            //Max value location markers

            this.markerMax = new THREE.ArrowHelper(
                new THREE.Vector3( 1, 0, 0),
                new THREE.Vector3( 0, 0, 0 ),
                HIGHLIGHT_SIZE*30,
                0x111111
            );
            this.markerMax.line.material.depthTest = false;
            this.markerMax.visible = false;
            this.scene.add(this.markerMax);

            this.markerMin = new THREE.ArrowHelper(
                new THREE.Vector3( 1, 0, 0),
                new THREE.Vector3( 0, 0, 0 ),
                HIGHLIGHT_SIZE*30,
                0x111111
            );
            this.markerMin.line.material.depthTest = false;
            this.markerMin.visible = false;
            this.scene.add(this.markerMin);

            this.listenTo(this.model, "change:result", this.minMaxUpdate);

            // Add widgets
            this.options = new Options({model: this.model});
            this.$el.append(this.options.render().$el);
            this.listenTo(this.options, 'minMaxNeedsUpdate', this.minMaxUpdate);

            this.query = new Query({model: this.model});
            this.$el.append(this.query.render().$el);

            this.legend = new Legend({model: this.model});
            this.$el.append( this.legend.$el );
            this.legend.render();

            this.minVert = new minMaxVert({model: this.model});
            this.minVert.name = 'Min: ';
            this.$el.append( this.minVert.render().$el );

            this.maxVert = new minMaxVert({model: this.model});
            this.maxVert.name = 'Max: ';
            this.$el.append( this.maxVert.render().$el );

            this.loader.remove();

            this.animate();

        },

        animate: function () {
            this.animationFrame = requestAnimationFrame( this.animate.bind(this) );
            this.controls.update();
            this.checkHighlight();

            var scale = 1/this.camera.zoom;
            this.markerSelect.scale.set(scale, scale, scale);
            this.markerHighlight.scale.set(scale, scale, scale);

            this.updateArrows(scale);

            this.renderer.render(this.scene, this.camera);
        },

        updateMouse: function (event) {
            mouse.x = ( event.offsetX / this.$el.width() ) * 2 - 1;
            mouse.y = - ( event.offsetY / this.$el.height() ) * 2 + 1;
        },

        /**
         * Check if point is visible under current viewcuts
         * @param {THREE.Vector3} point - point to check for visibility
         */
        _isVisible: function (point) {
            if (!this.model.get('viewcuts').length) return true;

            var VIEWCUT_OPERATOR = {
                'intersection': function (a, b) { return a && b; },
                'union': function (a, b) { return a || b; },
                'difference': function (a, b) { return a != b; }
            };
            var op = VIEWCUT_OPERATOR[ this.model.get('viewcutMode') ];

            var viewcut = this.model.get('viewcuts')[0];
            var show = point.clone().sub(viewcut.point).dot(viewcut.normal) > 0;

            for ( var i = 1; i < this.model.get('viewcuts').length; i++ ) {
                viewcut = this.model.get('viewcuts')[i];
                show = op(show, point.clone().sub(viewcut.point).dot(viewcut.normal) > 0);
            }

            return show;
        },

        checkHighlight: function () {
            this.raycaster.setFromCamera(mouse, this.camera);
            var intersectedNodes = this.raycaster.intersectObject(this.model.nodes);
            var intersectedElements = this.raycaster.intersectObject(this.model.mesh);

            intersectedNodes = _.filter(intersectedNodes,
                                        function (val) {
                                            return this._isVisible(val.point);
                                        }.bind(this));
            intersectedElements = _.filter(intersectedElements,
                                           function (val) {
                                               return this._isVisible(val.point);
                                           }.bind(this));

            if (intersectedElements.length && intersectedNodes.length) {
                if ( Math.abs(intersectedElements[0].distance - intersectedNodes[0].distance) < HIGHLIGHT_THRESHOLD ) {
                    var pointIndex = intersectedNodes[0].index;
                    var positionArray = intersectedNodes[0].object.geometry.attributes.position.array;
                    var point = new THREE.Vector3().fromArray(positionArray, 3*pointIndex);

                    this.markerHighlight.position.copy(point);
                    this.markerHighlight.visible = true;
                    INTERSECTED = pointIndex;
                    return;
                }
            }

            this.markerHighlight.visible = false;
            INTERSECTED = null;
        },

        selectNode: function () {
            if (INTERSECTED == null) {
                this.markerSelect.visible = false;
                radio.trigger("node:selected");
            } else {
                radio.trigger("node:selected", INTERSECTED);
                this.markerSelect.position.copy(this.markerHighlight.position);
                this.markerSelect.visible = true;
            };
        },

        selectRotationCenter: function (event) {
            if (!event.ctrlKey) return;

            if (INTERSECTED == null) {
                this.rotationCenter.position.copy(this.model.mesh.geometry.boundingSphere.center);
                this.camera.position.add(this.rotationCenter.position).sub(this.controls.target);
                this.controls.target.copy(this.rotationCenter.position);
            } else {
                this.rotationCenter.position.copy(this.markerHighlight.position);
                this.camera.position.add(this.rotationCenter.position).sub(this.controls.target);
                this.controls.target.copy(this.rotationCenter.position);
            };
        },

        onResize: function () {
            requestAnimationFrame( this.handleResize.bind(this) );
        },

        handleResize: function () {
            var sceneSize = this.model.mesh.geometry.boundingSphere.radius;
            this.renderer.setSize( this.$el.width(), this.$el.height() );
            this.camera.left = -sceneSize * this.$el.width() / this.$el.height();
            this.camera.right = sceneSize * this.$el.width() / this.$el.height();
            this.camera.updateProjectionMatrix();
            this.controls.handleResize();
            this.legend.render();
        },

        /**
         * Function to find min and max highlighting locations
         * Triggered by Options view
         */
        minMaxUpdate: function() {

            var attrName = this.model.get("result");
            if (!attrName) {
                this.markerMax.visible = false;
                this.markerMin.visible = false;
                return;
            }
            var array = this.model.data.getAttribute(attrName).array;
            var nodeCoor = this.model.nodes.geometry.attributes.position.array;
            var vertexMin;
            var vertexMax;

            //find Frustum - visible part of viewport based on camera data
            this.camera.updateMatrix();
            this.camera.updateMatrixWorld();
            var frustum = new THREE.Frustum();
            frustum.setFromMatrix( new THREE.Matrix4().multiplyMatrices(this.camera.projectionMatrix, this.camera.matrixWorldInverse ) );

            var atest;
            var inView = 0;  //counter of nodes in view

            for ( var i = 0; i < array.length; i++ )
            {
                //check if a node is within the viewport
                atest = new THREE.Vector3( nodeCoor[i*3], nodeCoor[i*3+1], nodeCoor[i*3+2]);

                if (frustum.containsPoint(atest)) {

                    //check if a node is visible according to viewcuts
                    if ( this._isVisible(atest) ) {

                        //TODO: check if a node is not occluded by mesh (raycaster is too slow)

                        if(inView == 0) {
                            vertexMin = i;
                            vertexMax = i;
                        };

                        inView = inView + 1;

                        if (array[i] <= array[vertexMin]) {
                            vertexMin = i;
                        };

                        if (array[i] >= array[vertexMax]) {
                            vertexMax = i;
                        };

                    };

                };

            };

            //if at least 3 nodes are visible
            if(inView>2) {

                //vertices for current display min/max (not global min/max)
                this.maxVert.vertexNum = vertexMax;
                this.minVert.vertexNum = vertexMin;
                this.maxVert.render();
                this.minVert.render();

                this.markerMax.visible = true;
                this.markerMin.visible = true;
            };

        },

        /**
         * Function to update min and max highlighting locations (arrows, labels)
         */

        updateArrows: function(scale) {

            if(this.markerMax.visible && this.markerMin.visible) {

                var vertexMin = this.minVert.vertexNum;
                var vertexMax = this.maxVert.vertexNum;
                var nodeCoor = this.model.nodes.geometry.attributes.position.array;

                var arrLength = HIGHLIGHT_SIZE*30*scale;

                // calculate max arrow origin and direction
                var targetMax = new THREE.Vector3().fromArray(nodeCoor, 3*vertexMax);
                var dirMax = this.rotationCenter.position.clone().sub(targetMax);

                if (dirMax.length() < HIGHLIGHT_SIZE) { // too close to rotation center
                    dirMax = this.model.mesh.geometry.boundingSphere.center.clone().sub(targetMax);
                }

                dirMax.normalize();
                var origMax = targetMax.clone().addScaledVector(dirMax, -arrLength);

                // calculate min arrow origin and direction
                var targetMin = new THREE.Vector3().fromArray(nodeCoor, 3*vertexMin);
                var dirMin = this.rotationCenter.position.clone().sub(targetMin);

                if (dirMin.length() < HIGHLIGHT_SIZE) { // too close to rotation center
                    dirMin = this.model.mesh.geometry.boundingSphere.center.clone().sub(targetMin);
                }

                dirMin.normalize();
                var origMin = targetMin.clone().addScaledVector(dirMin, -arrLength);

                // set arrows origins and directions
                this.markerMax.position.copy(origMax);
                this.markerMax.setDirection(dirMax);
                this.markerMax.scale.set(scale, scale, scale);

                this.markerMin.position.copy(origMin);
                this.markerMin.setDirection(dirMin);
                this.markerMin.scale.set(scale, scale, scale);

                // transformation matrix from WebGL clipspace to DOM element space
                var widthHalf = 0.5*this.renderer.context.canvas.width;
                var heightHalf = 0.5*this.renderer.context.canvas.height;

                var clipspaceToScreen = new THREE.Matrix4().set(
                    widthHalf, 0, 0, widthHalf + 15,
                    0, -heightHalf, 0, heightHalf,
                    0, 0, 1, 0,
                    0, 0, 0, 1
                );

                // move max label
                origMax.project(this.camera).applyProjection(clipspaceToScreen);
                targetMax.project(this.camera).applyProjection(clipspaceToScreen).sub(origMax);

                this.maxVert.translate(origMax, targetMax);

                // move min label
                origMin.project(this.camera).applyProjection(clipspaceToScreen);
                targetMin.project(this.camera).applyProjection(clipspaceToScreen).sub(origMin);

                this.minVert.translate(origMin, targetMin);
                
                this.markerSelect.visible = true;
                this.markerHighlight.visible = true;

            };
        }

    });

    return Viewport;
});
