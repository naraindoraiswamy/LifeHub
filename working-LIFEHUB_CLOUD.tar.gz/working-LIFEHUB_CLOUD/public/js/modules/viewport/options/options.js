/**
 * @fileOverview Options widget view
 * @name options.js
 * @author Alexey Stytsenko <alexey.stytsenko@ge.com>
 */
define(function(require) {
    "use strict";

    var Backbone = require("backbone");
    var _ = require('underscore');
    require("modelbinder");
    var THREE = require("three");
    require('bootstrap_toggle');

    var BLUE_TO_RED = [
        new THREE.Color(0.164, 0.043, 0.850),
        new THREE.Color(0.150, 0.306, 1.000),
        new THREE.Color(0.250, 0.630, 1.000),
        new THREE.Color(0.450, 0.853, 1.000),
        new THREE.Color(0.670, 0.973, 1.000),
        new THREE.Color(0.880, 1.000, 1.000),
        new THREE.Color(1.000, 1.000, 0.750),
        new THREE.Color(1.000, 0.880, 0.600),
        new THREE.Color(1.000, 0.679, 0.450),
        new THREE.Color(0.970, 0.430, 0.370),
        new THREE.Color(0.850, 0.150, 0.196),
        new THREE.Color(0.650, 0.000, 0.130)
    ];
    var RED_TO_BLUE = BLUE_TO_RED.slice();
    RED_TO_BLUE.reverse();

    var View = Backbone.View.extend({

        tagName: "div",
        className: "options",

        template: require("hbs!./options"),

        events: {
            'hide.bs.collapse #options-accordion': 'toggleMenu',
            'show.bs.collapse #options-accordion': 'toggleMenu',
            'change .js-viewcut-toggle input': 'toggleViewcut',
            'change .js-viewcut-flip input': 'flipViewcut',
            'change .js-viewcut-control input[type=range]': 'onSliderChange',
            'mousedown .js-viewcut-control input[type=range]': 'onSliderChangeMouse',
            'touchstart .js-viewcut-control input[type=range]': 'onSliderChangeTouch',
            'click .js-maxColor-colormap': function () {
                var colormap = this.model.get('colorMap');
                this.model.set('maxColor', colormap[colormap.length - 1]);
            },
            'click .js-minColor-colormap': function () {
                var colormap = this.model.get('colorMap');
                this.model.set('minColor', colormap[0]);
            },
            'change .js-colormap': function (e) {
                switch ( $(e.target).val() ) {
                case 'blue-to-red':
                    this.model.set('colorMap', BLUE_TO_RED);
                    break;
                case 'red-to-blue':
                    this.model.set('colorMap', RED_TO_BLUE);
                    break;
                }
            },
            'click .js-findMinMax': function ()  {
                this.trigger('minMaxNeedsUpdate');
            }
        },

        _viewcuts: [
            { id: 'Viewcut X',
              active: false,
              inverse: 1,
              point: new THREE.Vector3(0, 0, 0),
              normal: new THREE.Vector3(1, 0, 0) },
            { id: 'Viewcut Y',
              active: false,
              inverse: 1,
              point: new THREE.Vector3(0, 0, 0),
              normal: new THREE.Vector3(0, 1, 0) },
            { id: 'Viewcut Z',
              active: false,
              inverse: 1,
              point: new THREE.Vector3(0, 0, 0),
              normal: new THREE.Vector3(0, 0, 1) }
        ],

        initialize: function () {
            this.binder = new Backbone.ModelBinder();

            _.each(this._viewcuts, function(elem) {
                elem.point = this.model.mesh.geometry.boundingSphere.center.clone();
            }, this);
        },

        remove: function () {
            this.binder.unbind();
            Backbone.View.prototype.remove.apply(this, arguments);
            return this;
        },

        render: function () {
            this.$el.html(this.template({
                viewcuts: this._viewcuts,
                radius: Math.ceil(this.model.mesh.geometry.boundingSphere.radius)
            }));

            var bindings = Backbone.ModelBinder.createDefaultBindings(this.el, 'name');

            var colorConverter = function(direction, value) {
                if (direction === Backbone.ModelBinder.Constants.ModelToView) {
                    return '#' + value.getHexString();
                } else {
                    return new THREE.Color(value);
                }
            };

            bindings['maxColor'].converter = colorConverter;
            bindings['minColor'].converter = colorConverter;

            this.binder.bind(this.model, this.el, bindings);

            this.$('input[type=checkbox][data-toggle^=toggle]').bootstrapToggle();

            return this;
        },

        /**
         * Toggle class and rotate menu arrow when menu section opened/closed
         */
        toggleMenu: function (e) {
            $(e.target)
                .prev('.panel-heading')
                .find('i.indicator')
                .toggleClass('glyphicon-menu-right glyphicon-menu-down');
        },

        /**
         * Set 'viewcuts' display model attribute
         * View has internal _viewcuts hash which holds all viewcuts available for control
         * This function selects only active viewcuts and passes point&normal to display model
         */
        setViewcuts: function () {
            var viewcuts = _.where(this._viewcuts, {active: true});
            viewcuts = _.map(viewcuts, function (val) {
                return _.pick(val, 'point', 'normal');
            });
            this.model.set('viewcuts', viewcuts);
        },

        /**
         * Helper function to find which viewcut from _viewcuts is controlled by $elem
         * @param {} $elem - jQuery object referencing UI element
         */
        getViewcutByElem: function ($elem) {
            var viewcutID = $elem.closest('.js-viewcut-control').attr('data-viewcutID');
            return _.findWhere(this._viewcuts, {id: viewcutID});
        },

        /**
         * Toggle viewcut active state
         */
        toggleViewcut: function (e) {
            var $target = $(e.target);
            var viewcut = this.getViewcutByElem($target);

            viewcut.active = $target.prop('checked');
            this.setViewcuts();
        },

        /**
         * Flip viewcut normal
         */
        flipViewcut: function (e) {
            var $target = $(e.target);
            var viewcut = this.getViewcutByElem($target);

            viewcut.normal.negate();
            viewcut.inverse *= -1;
        },

        /**
         * Helper function to shift viewcut in direction of it's normal by alpha
         * if normal is not flipped, or by -alpha if flipped
         * @param {} viewcut - viewcut from _viewcuts to shift
         * @param {} alpha - shift distance
         */
        shiftViewcut: function (viewcut, alpha) {
            var center = this.model.mesh.geometry.boundingSphere.center.clone();
            viewcut.point.copy(center).addScaledVector( viewcut.normal, alpha * viewcut.inverse );
        },

        /**
         * Shift viewcut on 'change' event
         */
        onSliderChange: function (e) {
            var $target = $(e.target);
            var viewcut = this.getViewcutByElem($target);

            this.shiftViewcut(viewcut, $target.val());
        },

        /**
         * Shift viewcut if dragged by mouse
         */
        onSliderChangeMouse: function (e) {
            var $target = $(e.target);
            var viewcut = this.getViewcutByElem($target);

            $target.on('mousemove', function () {
                this.shiftViewcut(viewcut, $target.val());
            }.bind(this));

            $target.on('mouseup', function () {
                $target.off('mousemove');
                $target.off('mouseup');
            });
        },

        /**
         * Shift viewcut if dragged by touch
         */
        onSliderChangeTouch: function (e) {
            var $target = $(e.target);
            var viewcut = this.getViewcutByElem($target);

            $target.on('touchmove', function () {
                this.shiftViewcut(viewcut, $target.val());
            }.bind(this));

            $target.on('touchend', function () {
                $target.off('touchmove');
                $target.off('touchend');
            });
        }
    });

    return View;
});
