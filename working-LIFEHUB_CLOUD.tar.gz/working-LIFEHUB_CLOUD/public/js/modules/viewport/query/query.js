define(function(require) {
    "use strict";

    var Backbone = require("backbone");
    var radio = require("radio").channel("app");

    var View = Backbone.View.extend({

        tagname: "div",
        className: "query-window",

        template: require("hbs!./query"),

        initialize: function() {
            radio.on("node:selected", this.render, this);
        },

        render: function (vIndex) {
            if (vIndex) {
                var queryData = this.model.queryNode(vIndex);
                queryData.TDAM = queryData.TDAM.toFixed(2);
                queryData.SIGR = (queryData.SIGR / 1e6).toFixed(2);
                queryData.CYCL = Math.round(queryData.CYCL);
                this.$el.html(this.template(queryData));
                this.$el.show();
            } else {
                this.$el.hide();
            };
            return this;
        },

        remove: function () {
            radio.off("node:selected", this.render);
            Backbone.View.prototype.remove.apply(this, arguments);
            return this;
        }
    });

    return View;
});
