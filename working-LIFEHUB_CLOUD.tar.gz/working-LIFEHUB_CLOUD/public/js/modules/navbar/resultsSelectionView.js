/**
 * @fileOverview View for display model result selection
 * @name resultsSelectionView.js
 * @author Alexey Stytsenko <alexey.stytsenko@ge.com>
 */
define( function (require) {
    'use strict';

    var Backbone = require('backbone');

    var resultsSelectionView = Backbone.View.extend({
        tagName: 'li',
        className: 'dropdown',

        template: require('hbs!./resultsSelectionView'),

        events: {
            'click li a': 'selectResult'
        },

        initialize: function () {
            this.listenTo(this.model, 'change:result', this.render);
        },

        render: function () {
            this.$el.html( this.template({
                selectedResult: this.model.get('result')
            }) );

            return this;
        },

        selectResult: function (e) {
            e.preventDefault();
            var $target = $(e.target);
            this.model.set('result', $target.attr('href'));
        }

    });

    return resultsSelectionView;
});
